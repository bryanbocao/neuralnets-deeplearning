## Student: Bo Cao
## Email: bo.cao-1@colorado.edu or boca7588@colorado.edu
## Github: https://github.com/BryanBo-Cao/neuralnets-deeplearning

## Environment:
python 2.7.10

## ToRun:
Open a terminal, cd to "assignment*" directory, run ```python part*.py``` directly.

For instance, if you want to run ```part1.py``` code, type ```python part1.py```.

3 parts solutions are ```part1.py```, ```part2.py``` and ```part3.py``` respectively, I've put a lot of efforts in this assignment, each part's code was written from scratch.
